import {Course} from './course';
export class Student{
	id: number;
	studentId: string;
	name: string;
	surname: string;
	gpa: number;
	image: string;
	featured:boolean;
	penAmount:number;
	description:string;
  enrolledCourse:Course[];

}
