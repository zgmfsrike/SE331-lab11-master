export class Course{
  courseId:string;
  courseName:string;
  id:number;
}
