import {Component} from '@angular/core';
@Component({
 selector: 'file-not-found',
 templateUrl: './file-not-found.component.html',
 styleUrls:['./file-not-found.component.css']
})
export class FileNotFoundComponent {

}
